<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package pro-headphones
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
 
        <?php
if ( is_single() ) {
    the_title( '<h2 class="entry-title">', '</h2>' );
} else {
    the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
}

if ( 'post' === get_post_type() ) : ?>
       
        <div class="blog-post">
            <!--           add image-->
            <?php the_post_thumbnail(); ?>

            <?php if(is_home()) { ?> 
            <p><?php the_excerpt(); ?></p>
            <?php } else { ?>
            <p><?php the_content(); ?></p>
            <?php } ?>

            <div class="callout">
                <ul class="menu simple">
                    <li><a href="#">Author: <?php the_author(); ?></a></li>
                    <li><a href="#"><?php comments_number(); ?></a></li>

                    <!-- Date function: Use 'echo get_the_date()' instead of 'the_date()'. 'the_date()' only shows the date for the first post of the day.  -->
                    <li><a href="#">Posted on: <?php echo get_the_date('F j, Y'); ?></a></li>
                </ul>
            </div>
        </div>
        
        <?php
endif; ?>

</article><!-- #post-## -->
